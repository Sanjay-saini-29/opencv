@echo off
echo Setting up Stress-Strain Graph Analyzer...

REM Create virtual environment
python -m venv venv
echo Virtual environment created

REM Activate virtual environment and install dependencies
call venv\Scripts\activate.bat
pip install --upgrade pip
pip install -r requirements.txt
echo Dependencies installed

REM Create necessary directories
mkdir uploads 2>nul
mkdir outputs 2>nul
echo Directories created

REM Test the installation
echo Testing installation...
python test_cv.py

echo.
echo Setup complete!
echo To start the application:
echo   venv\Scripts\activate.bat
echo   python run.py
echo.
echo Then open: http://localhost:5000

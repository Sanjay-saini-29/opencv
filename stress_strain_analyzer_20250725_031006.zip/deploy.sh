#!/bin/bash
# Quick deployment script for Stress-Strain Graph Analyzer

echo "🚀 Setting up Stress-Strain Graph Analyzer..."

# Create virtual environment
python3 -m venv venv
echo "✅ Virtual environment created"

# Activate virtual environment and install dependencies
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
echo "✅ Dependencies installed"

# Create necessary directories
mkdir -p uploads outputs
echo "✅ Directories created"

# Test the installation
echo "🔍 Testing installation..."
python test_cv.py

echo ""
echo "🎉 Setup complete!"
echo "💡 To start the application:"
echo "   source venv/bin/activate"
echo "   python run.py"
echo ""
echo "📱 Then open: http://localhost:5000"

# 🚀 QUICK START GUIDE

## Your Stress-Strain Graph Analyzer is Ready!

### 📥 What You Downloaded:
- Complete web application for analyzing stress-strain graphs
- Advanced computer vision that accurately detects plot lines
- Solves the "too many lines detected" problem with smart clustering
- Exports data to Excel with separate sheets per temperature line
- Shows annotated images of detected points

### 🛠️ Installation (Choose Your OS):

#### 🐧 Linux/Mac:
```bash
# Extract this zip file first, then:
chmod +x install.sh
./install.sh
```

#### 🪟 Windows:
```cmd
# Extract this zip file first, then:
install.bat
```

### 🚀 Running the Application:

#### Linux/Mac:
```bash
source venv/bin/activate
python run.py
```

#### Windows:
```cmd
venv\Scripts\activate.bat
python run.py
```

### 📱 Using the App:
1. Open: http://localhost:5000
2. Upload your stress-strain graph image
3. Download Excel file with extracted data
4. Download annotated image showing detected points

### 🎯 Key Features:
- ✅ Accurate line counting (no more 20 lines when you have 5!)
- ✅ Ignores legends and temperature indicators
- ✅ Groups similar colored pixels into single lines
- ✅ Excel output with data organized by temperature
- ✅ Visual verification of detected points

### 🆘 Need Help?
- Run: `python test_cv.py` to verify installation
- Check README.md for detailed documentation
- All code is well-commented for easy understanding

### 🎉 You're Ready to Analyze!
Upload your graphs and get accurate, structured data in seconds!

@echo off
echo Installing Stress-Strain Graph Analyzer...
echo ================================================

REM Check Python
python --version >nul 2>&1 || (echo Python is required & exit /b 1)

REM Create virtual environment
echo Creating virtual environment...
python -m venv venv
call venv\Scripts\activate.bat

REM Upgrade pip
echo Upgrading pip...
pip install --upgrade pip

REM Install requirements
echo Installing dependencies...
pip install -r requirements.txt

REM Create directories
echo Creating directories...
mkdir uploads 2>nul
mkdir outputs 2>nul

REM Test installation
echo Testing installation...
python test_cv.py

echo.
echo Installation Complete!
echo To start the application:
echo   venv\Scripts\activate.bat
echo   python run.py
echo.
echo Then open: http://localhost:5000
echo ================================================

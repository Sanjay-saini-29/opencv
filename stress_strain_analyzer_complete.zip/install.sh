#!/bin/bash
echo "🚀 Installing Stress-Strain Graph Analyzer..."
echo "================================================"

# Check Python version
python3 --version || { echo "❌ Python 3 is required"; exit 1; }

# Create virtual environment
echo "📦 Creating virtual environment..."
python3 -m venv venv
source venv/bin/activate

# Upgrade pip
echo "⬆️  Upgrading pip..."
pip install --upgrade pip

# Install requirements
echo "📥 Installing dependencies..."
pip install -r requirements.txt

# Create directories
echo "📁 Creating directories..."
mkdir -p uploads outputs

# Test installation
echo "🔍 Testing installation..."
python test_cv.py

echo ""
echo "🎉 Installation Complete!"
echo "🚀 To start the application:"
echo "   source venv/bin/activate"
echo "   python run.py"
echo ""
echo "📱 Then open: http://localhost:5000"
echo "================================================"
